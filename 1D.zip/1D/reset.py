"""
manually reset game board
"""

from multiplayer import *

game = {}
initialize(game)
setData(game)