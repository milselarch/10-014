# betting-tictactoe

How to run:
In terminal, run main.py like so:
python3 main.py

